$(function() {
    $('form').submit(function() {
        return false
    });    
    $('#submitBtn').click (function() {
        $('form').submit(function() {
            // var temp;
            // temp = $(this).serializeArray();
            $.each($(this).serializeArray(), function (i, field) {
                // console.log(temp);
                $('td:nth-child(' + (i+1) + ')' ).text(field.value);
            });
        });
    });
});


//ver2.0
// $(function() {
//     $('form').submit(function() {
//         return false
//     });    
//     $('#submitBtn').click (function() {
//         $('form').submit(function() {
//             // var temp;
//             // temp = $(this).serializeArray();
//             $.each($(this).serializeArray(), function (i, field) {
//                 // console.log(temp);
//                 $('td:nth-child(' + (i+1) + ')' ).text(field.value);
//             });
//         });
//     });
// });
