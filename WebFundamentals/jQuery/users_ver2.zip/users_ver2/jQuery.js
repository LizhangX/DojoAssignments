$(function() {
    $('form').submit(function() {
        return false
    });    
    $('#submitBtn').click (function() {
        // $('form').submit();
        $('tbody').append('<tr></tr>');
        $.each($('form').serializeArray(), function (i,field) {
            $('tbody tr:last-child').append('<td>' + field.value + '</td>');
        });
    });
});



